// import 'package:flutter_secure_storage/flutter_secure_storage.dart';

// class SecureStorage {
//   final _storage = const FlutterSecureStorage();

//   Future<void> setLoginStatus(String key, String value) async {
//     await _storage.write(key: key, value: value);
//   }

//   Future<String?> getLoginStatus(String key) async {
//     return await _storage.read(key: key);
//   }

//   Future<void> setHomeId(String key, int value) async {
//     await _storage.write(key: key, value: value.toString());
//   }

//   Future<String?> getHomeId(String key) async {
//     return await _storage.read(key: key);
//   }
// }
