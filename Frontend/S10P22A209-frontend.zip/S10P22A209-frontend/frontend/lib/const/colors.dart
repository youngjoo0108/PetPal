import 'package:flutter/material.dart';

const lightYellow = Color.fromARGB(255, 255, 254, 241);
const deepYellow = Color.fromARGB(255, 255, 242, 161);
const logout = Color.fromARGB(255, 0, 0, 0);
const white = Colors.white;
const blue = Colors.blue;
const black = Colors.black;
