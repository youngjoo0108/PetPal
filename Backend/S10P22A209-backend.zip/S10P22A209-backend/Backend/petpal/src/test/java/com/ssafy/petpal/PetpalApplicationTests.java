package com.ssafy.petpal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetpalApplicationTests {

	@Test
	void contextLoads() {
	}

}
