package com.ssafy.petpal.home.dto;

import lombok.*;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HomeRequestDTO {

    private Long userId;

//    private String homeNickname;

}
