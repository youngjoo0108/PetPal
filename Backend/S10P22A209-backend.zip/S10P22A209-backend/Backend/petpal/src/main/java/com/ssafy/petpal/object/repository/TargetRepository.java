package com.ssafy.petpal.object.repository;

import com.ssafy.petpal.object.entity.Target;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TargetRepository extends JpaRepository<Target,Long> {

}
