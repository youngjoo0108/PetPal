package com.ssafy.petpal.auth.dto;

import lombok.Getter;

@Getter
public class OauthRequestDto {
    private String accessToken;
}
